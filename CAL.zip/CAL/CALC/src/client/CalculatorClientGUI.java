package client;

import common.Calculator;

import javax.swing.*;
import java.awt.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalculatorClientGUI extends JFrame {

    private JTextField display;
    private Calculator calc;
    private double first = 0;
    private String op = "";

    public CalculatorClientGUI() {
        setTitle("RMI Calculator");
        setSize(300, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        display = new JTextField();
        display.setFont(new Font("Arial", Font.BOLD, 22));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        add(display, BorderLayout.NORTH);

        JPanel p = new JPanel(new GridLayout(5, 4));

        String[] b = {
                "7","8","9","/",
                "4","5","6","*",
                "1","2","3","-",
                "0","C","=","+",
                "sin","cos","tan","√"
        };

        for (String s : b) {
            JButton btn = new JButton(s);
            btn.addActionListener(e -> press(s));
            p.add(btn);
        }

        add(p);
        connect();
    }

    private void connect() {
        try {
            Registry r = LocateRegistry.getRegistry("localhost", 1099);
            calc = (Calculator) r.lookup("CalcService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Server not running");
            System.exit(0);
        }
    }

    private void press(String s) {
        try {
            if (s.matches("[0-9]")) {
                display.setText(display.getText() + s);
                return;
            }

            if (s.equals("C")) {
                display.setText("");
                op = "";
                return;
            }

            if ("+-*/".contains(s)) {
                first = Double.parseDouble(display.getText());
                op = s;
                display.setText("");
                return;
            }

            if (s.equals("=")) {
                double second = Double.parseDouble(display.getText());
                double r = 0;

                if (op.equals("+")) r = calc.add(first, second);
                if (op.equals("-")) r = calc.subtract(first, second);
                if (op.equals("*")) r = calc.multiply(first, second);
                if (op.equals("/")) r = calc.divide(first, second);

                display.setText(String.valueOf(r));
                return;
            }

            double v = Double.parseDouble(display.getText());
            if (s.equals("sin")) display.setText("" + calc.sin(v));
            if (s.equals("cos")) display.setText("" + calc.cos(v));
            if (s.equals("tan")) display.setText("" + calc.tan(v));
            if (s.equals("√")) display.setText("" + calc.sqrt(v));

        } catch (Exception e) {
            display.setText("Undefined");
        }
    }

    public static void main(String[] args) {
        new CalculatorClientGUI().setVisible(true);
    }
}
