import java.io.*;
import java.net.Socket;

class ClientHandler extends Thread {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private DataInputStream dataIn;
    private DataOutputStream dataOut;

    ClientHandler(Socket socket) {
        this.socket = socket;
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            dataIn = new DataInputStream(socket.getInputStream());
            dataOut = new DataOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            String header;
            while ((header = in.readLine()) != null) {

                if (header.startsWith("MSG|")) {
                    ChatServer.broadcast(header, this);
                }

                else if (header.startsWith("FILE|")) {
                    String[] parts = header.split("\\|");
                    long size = Long.parseLong(parts[3]);

                    byte[] fileData = dataIn.readNBytes((int) size);
                    ChatServer.broadcastFile(header, fileData, this);
                }
            }
        } catch (IOException e) {
            System.out.println("Client disconnected");
        } finally {
            ChatServer.removeClient(this);
        }
    }

    void sendMessage(String msg) {
        out.println(msg);
    }

    void sendFile(String header, byte[] fileData) throws IOException {
        out.println(header);
        dataOut.write(fileData);
        dataOut.flush();
    }
}
