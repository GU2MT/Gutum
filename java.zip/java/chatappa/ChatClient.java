import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ChatClient {

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private DataInputStream dataIn;
    private DataOutputStream dataOut;

    private JFrame frame;
    private JTextArea chatArea;
    private JTextField inputField;
    private JLabel statusLabel;

    private String username;

    public ChatClient() {
        username = JOptionPane.showInputDialog(
                null,
                "Enter your username:",
                "Login",
                JOptionPane.PLAIN_MESSAGE
        );

        if (username == null || username.isBlank()) {
            username = "User";
        }

        buildGUI();
        connectToServer();
        startReceiving();
    }

    // ================= GUI =================
    private void buildGUI() {
        frame = new JFrame("Chat Client - " + username);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);

        inputField = new JTextField();
        JButton sendBtn = new JButton("Send");
        JButton fileBtn = new JButton("Send File");

        statusLabel = new JLabel("Not connected");

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.add(inputField, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        buttons.add(sendBtn);
        buttons.add(fileBtn);

        bottom.add(buttons, BorderLayout.EAST);

        frame.setLayout(new BorderLayout());
        frame.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        frame.add(bottom, BorderLayout.SOUTH);
        frame.add(statusLabel, BorderLayout.NORTH);

        frame.setSize(500, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        sendBtn.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
        fileBtn.addActionListener(e -> sendFile());
    }

    // ================= NETWORK =================
    private void connectToServer() {
        try {
            socket = new Socket("localhost", 5000);

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            dataIn = new DataInputStream(socket.getInputStream());
            dataOut = new DataOutputStream(socket.getOutputStream());

            statusLabel.setText("Connected to server");
            chatArea.append("Connected successfully\n");

        } catch (IOException e) {
            statusLabel.setText("Connection failed");
            chatArea.append("❌ Cannot connect to server\n");
        }
    }

    // ================= SEND =================
    private void sendMessage() {
        String msg = inputField.getText().trim();
        if (msg.isEmpty()) return;

        out.println("MSG|" + username + "|" + msg);
        chatArea.append("Me: " + msg + "\n");
        inputField.setText("");
    }

    private void sendFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();

        new Thread(() -> {
            try (FileInputStream fis = new FileInputStream(file)) {

                out.println("FILE|" + username + "|" + file.getName() + "|" + file.length());

                byte[] buffer = fis.readAllBytes();
                dataOut.write(buffer);
                dataOut.flush();

                SwingUtilities.invokeLater(() ->
                        chatArea.append("📁 Sent file: " + file.getName() + "\n")
                );

            } catch (IOException e) {
                SwingUtilities.invokeLater(() ->
                        chatArea.append("❌ File send failed\n")
                );
            }
        }).start();
    }

    // ================= RECEIVE =================
    private void startReceiving() {
        new Thread(() -> {
            try {
                String header;

                while ((header = in.readLine()) != null) {

                    if (header.startsWith("MSG|")) {
                        String[] p = header.split("\\|", 3);
                        appendChat(p[1] + ": " + p[2]);
                    }

                    else if (header.startsWith("FILE|")) {
                        receiveFile(header);
                    }
                }
            } catch (IOException e) {
                appendChat("❌ Disconnected from server");
                statusLabel.setText("Disconnected");
            }
        }).start();
    }

    private void receiveFile(String header) throws IOException {
        String[] p = header.split("\\|");
        String sender = p[1];
        String fileName = p[2];
        long size = Long.parseLong(p[3]);

        byte[] data = dataIn.readNBytes((int) size);

        appendChat("📥 " + sender + " sent file: " + fileName);

        // show text file content
        if (fileName.endsWith(".txt")) {
            String text = new String(data, StandardCharsets.UTF_8);
            appendChat("📄 File Content:\n" + text);
        }
    }

    // ================= UTIL =================
    private void appendChat(String text) {
        SwingUtilities.invokeLater(() ->
                chatArea.append(text + "\n")
        );
    }

    // ================= MAIN =================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatClient::new);
    }
}
